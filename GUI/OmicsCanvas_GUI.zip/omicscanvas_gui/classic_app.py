from __future__ import annotations

import os
import sys
import shlex
from pathlib import Path
from typing import Any, Dict, Optional, List

try:
    from PySide6.QtCore import Qt, QProcess, QSize
    from PySide6.QtGui import QAction, QFont
    from PySide6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QSplitter, QTreeWidget, QTreeWidgetItem,
        QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QTextEdit, QFileDialog,
        QScrollArea, QFormLayout, QCheckBox, QComboBox, QSpinBox, QDoubleSpinBox,
        QMessageBox, QGroupBox, QPlainTextEdit
    )
except Exception as e:
    # Give a clear error message if user runs without GUI deps.
    raise SystemExit(
        "PySide6 is not installed. Install it with:\n\n"
        "  pip install PySide6\n\n"
        f"Original import error: {e}"
    )

from .tooling import discover_tools, ToolSpec, ArgumentSpec, preset_path, load_preset, save_preset


# -------------------------
# Widgets helpers
# -------------------------

def guess_is_path_arg(arg: ArgumentSpec) -> bool:
    key = (arg.display_name + " " + (arg.help or "")).lower()
    tokens = ["file", "path", "dir", "folder", "bam", "bed", "gff", "gtf", "fasta", "fastq", "out", "prefix", "matrix"]
    return any(t in key for t in tokens)


def guess_is_dir_arg(arg: ArgumentSpec) -> bool:
    key = (arg.display_name + " " + (arg.help or "")).lower()
    return "dir" in key or "folder" in key or "outdir" in key


class ArgWidget(QWidget):
    """A row widget: input + optional browse button."""

    def __init__(self, arg: ArgumentSpec, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.arg = arg

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.widget = None
        self.browse_btn: Optional[QPushButton] = None

        # Determine widget type
        action = (arg.action or "").lower()
        tname = (arg.type_name or "").lower()
        choices = arg.choices

        if action in ("store_true", "store_false"):
            w = QCheckBox()
            default = bool(arg.default) if arg.default is not None else (action == "store_false")
            w.setChecked(default)
            self.widget = w
            layout.addWidget(w)
        elif choices:
            w = QComboBox()
            for c in choices:
                w.addItem(str(c))
            if arg.default is not None and str(arg.default) in [str(c) for c in choices]:
                w.setCurrentText(str(arg.default))
            self.widget = w
            layout.addWidget(w)
        elif tname == "int":
            w = QSpinBox()
            # NOTE: Qt spin boxes are 32-bit signed int. Using wider ranges
            # triggers libshiboken overflow on some platforms.
            w.setRange(-(2**31), 2**31 - 1)
            if arg.default is not None:
                try:
                    w.setValue(int(arg.default))
                except Exception:
                    pass
            self.widget = w
            layout.addWidget(w)
        elif tname == "float":
            w = QDoubleSpinBox()
            w.setDecimals(6)
            w.setRange(-1e18, 1e18)
            if arg.default is not None:
                try:
                    w.setValue(float(arg.default))
                except Exception:
                    pass
            self.widget = w
            layout.addWidget(w)
        else:
            w = QLineEdit()
            if arg.default not in (None, False):
                w.setText(str(arg.default))
            if arg.help:
                w.setPlaceholderText(arg.help[:80].replace("\n", " "))
            self.widget = w
            layout.addWidget(w, 1)

            if guess_is_path_arg(arg):
                self.browse_btn = QPushButton("Browse…")
                self.browse_btn.setFixedWidth(90)
                self.browse_btn.clicked.connect(self._browse)
                layout.addWidget(self.browse_btn)

        self.setLayout(layout)

    def _browse(self):
        if guess_is_dir_arg(self.arg):
            d = QFileDialog.getExistingDirectory(self, "Select directory", os.getcwd())
            if d:
                self.set_value(d)
        else:
            f, _ = QFileDialog.getOpenFileName(self, "Select file", os.getcwd(), "All files (*.*)")
            if f:
                self.set_value(f)

    def value(self) -> Any:
        action = (self.arg.action or "").lower()
        if isinstance(self.widget, QCheckBox):
            return self.widget.isChecked()
        if isinstance(self.widget, QComboBox):
            return self.widget.currentText()
        if isinstance(self.widget, QSpinBox):
            return int(self.widget.value())
        if isinstance(self.widget, QDoubleSpinBox):
            return float(self.widget.value())
        if isinstance(self.widget, QLineEdit):
            return self.widget.text().strip()
        return None

    def set_value(self, v: Any) -> None:
        if isinstance(self.widget, QCheckBox):
            self.widget.setChecked(bool(v))
        elif isinstance(self.widget, QComboBox):
            self.widget.setCurrentText(str(v))
        elif isinstance(self.widget, QSpinBox):
            try:
                self.widget.setValue(int(v))
            except Exception:
                pass
        elif isinstance(self.widget, QDoubleSpinBox):
            try:
                self.widget.setValue(float(v))
            except Exception:
                pass
        elif isinstance(self.widget, QLineEdit):
            self.widget.setText("" if v is None else str(v))


# -------------------------
# Main Window
# -------------------------

class MainWindow(QMainWindow):
    def __init__(self, root_dir: Path):
        super().__init__()
        self.root_dir = root_dir
        self.tools_dir = root_dir / "tools"
        self.docs_dir = root_dir / "docs"
        self.presets_dir = root_dir / "presets"
        self.logs_dir = root_dir / "logs"
        self.logs_dir.mkdir(parents=True, exist_ok=True)

        self.setWindowTitle("OmicsCanvas GUI")
        self.resize(1250, 780)

        self.tools: List[ToolSpec] = discover_tools(self.tools_dir, self.docs_dir)
        self.current_tool: Optional[ToolSpec] = None
        self.arg_widgets: Dict[str, ArgWidget] = {}

        self.proc: Optional[QProcess] = None

        self._build_menu()
        self._build_ui()
        self._populate_tree()

    # ----- UI -----
    def _build_menu(self):
        bar = self.menuBar()
        file_menu = bar.addMenu("File")

        act_open_logs = QAction("Open logs folder", self)
        act_open_logs.triggered.connect(self._open_logs_folder)
        file_menu.addAction(act_open_logs)

        act_quit = QAction("Quit", self)
        act_quit.triggered.connect(self.close)
        file_menu.addAction(act_quit)

        help_menu = bar.addMenu("Help")

        act_open_doc = QAction("Open selected tool manual", self)
        act_open_doc.triggered.connect(self._open_manual)
        help_menu.addAction(act_open_doc)

        act_about = QAction("About", self)
        act_about.triggered.connect(self._about)
        help_menu.addAction(act_about)

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        outer = QHBoxLayout(central)

        splitter = QSplitter(Qt.Horizontal)
        outer.addWidget(splitter)

        # Left: tool tree
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Tools"])
        self.tree.itemSelectionChanged.connect(self._on_select_tool)
        splitter.addWidget(self.tree)
        self.tree.setMinimumWidth(330)

        # Right: detail panel
        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(8, 8, 8, 8)
        splitter.addWidget(right)
        splitter.setStretchFactor(1, 1)

        # Settings row: python, cwd
        settings_box = QGroupBox("Run Settings")
        s_layout = QFormLayout(settings_box)

        self.python_edit = QLineEdit(sys.executable)
        btn_py = QPushButton("Browse…")
        btn_py.clicked.connect(self._browse_python)
        py_row = QWidget()
        py_row_l = QHBoxLayout(py_row)
        py_row_l.setContentsMargins(0, 0, 0, 0)
        py_row_l.addWidget(self.python_edit, 1)
        py_row_l.addWidget(btn_py)
        s_layout.addRow("Python executable", py_row)

        self.cwd_edit = QLineEdit(os.getcwd())
        btn_cwd = QPushButton("Browse…")
        btn_cwd.clicked.connect(self._browse_cwd)
        cwd_row = QWidget()
        cwd_row_l = QHBoxLayout(cwd_row)
        cwd_row_l.setContentsMargins(0, 0, 0, 0)
        cwd_row_l.addWidget(self.cwd_edit, 1)
        cwd_row_l.addWidget(btn_cwd)
        s_layout.addRow("Working directory", cwd_row)

        right_layout.addWidget(settings_box)

        # Tool header + actions
        header = QWidget()
        hl = QHBoxLayout(header)
        hl.setContentsMargins(0, 0, 0, 0)
        self.tool_title = QLabel("Select a tool on the left")
        font = QFont()
        font.setPointSize(14)
        font.setBold(True)
        self.tool_title.setFont(font)
        hl.addWidget(self.tool_title, 1)

        self.btn_manual = QPushButton("Manual")
        self.btn_manual.clicked.connect(self._open_manual)
        self.btn_manual.setEnabled(False)
        hl.addWidget(self.btn_manual)

        self.btn_load_preset = QPushButton("Load preset")
        self.btn_load_preset.clicked.connect(self._load_preset)
        self.btn_load_preset.setEnabled(False)
        hl.addWidget(self.btn_load_preset)

        self.btn_save_preset = QPushButton("Save preset")
        self.btn_save_preset.clicked.connect(self._save_preset)
        self.btn_save_preset.setEnabled(False)
        hl.addWidget(self.btn_save_preset)

        right_layout.addWidget(header)

        # Description
        self.desc = QPlainTextEdit()
        self.desc.setReadOnly(True)
        self.desc.setMaximumHeight(110)
        right_layout.addWidget(self.desc)

        # Args form (scroll)
        self.form_widget = QWidget()
        self.form_layout = QFormLayout(self.form_widget)
        self.form_layout.setLabelAlignment(Qt.AlignRight)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(self.form_widget)
        right_layout.addWidget(scroll, 1)

        # Command preview + buttons
        bottom = QWidget()
        bl = QVBoxLayout(bottom)
        bl.setContentsMargins(0, 0, 0, 0)

        cmd_row = QWidget()
        cmd_l = QHBoxLayout(cmd_row)
        cmd_l.setContentsMargins(0, 0, 0, 0)
        self.cmd_preview = QLineEdit()
        self.cmd_preview.setReadOnly(True)
        cmd_l.addWidget(QLabel("Command"))
        cmd_l.addWidget(self.cmd_preview, 1)
        btn_copy = QPushButton("Copy")
        btn_copy.clicked.connect(lambda: QApplication.clipboard().setText(self.cmd_preview.text()))
        cmd_l.addWidget(btn_copy)
        bl.addWidget(cmd_row)

        btn_row = QWidget()
        br = QHBoxLayout(btn_row)
        br.setContentsMargins(0, 0, 0, 0)
        self.btn_preview = QPushButton("Preview")
        self.btn_preview.clicked.connect(self._update_preview)
        br.addWidget(self.btn_preview)

        self.btn_run = QPushButton("Run")
        self.btn_run.clicked.connect(self._run)
        self.btn_run.setEnabled(False)
        br.addWidget(self.btn_run)

        self.btn_stop = QPushButton("Stop")
        self.btn_stop.clicked.connect(self._stop)
        self.btn_stop.setEnabled(False)
        br.addWidget(self.btn_stop)
        br.addStretch(1)
        bl.addWidget(btn_row)

        # Log window
        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setMinimumHeight(180)
        bl.addWidget(QLabel("Log"))
        bl.addWidget(self.log)

        right_layout.addWidget(bottom)

    def _populate_tree(self):
        self.tree.clear()
        cats: Dict[str, QTreeWidgetItem] = {}
        for t in self.tools:
            if t.category not in cats:
                cats[t.category] = QTreeWidgetItem([t.category])
                cats[t.category].setExpanded(True)
                self.tree.addTopLevelItem(cats[t.category])
            # keep the navigation clean: show functional title instead of numeric IDs
            item = QTreeWidgetItem([t.title])
            item.setData(0, Qt.UserRole, t.id)
            cats[t.category].addChild(item)

    # ----- events -----
    def _on_select_tool(self):
        items = self.tree.selectedItems()
        if not items:
            return
        item = items[0]
        tool_id = item.data(0, Qt.UserRole)
        if not tool_id:
            return
        tool = next((x for x in self.tools if x.id == tool_id), None)
        if not tool:
            return
        self.load_tool(tool)

    def load_tool(self, tool: ToolSpec):
        self.current_tool = tool
        self.tool_title.setText(f"{tool.id} — {tool.title}")
        self.desc.setPlainText(tool.description or "")

        self.btn_manual.setEnabled(bool(tool.docs_path))
        self.btn_load_preset.setEnabled(True)
        self.btn_save_preset.setEnabled(True)
        self.btn_run.setEnabled(True)

        # clear form
        while self.form_layout.rowCount():
            self.form_layout.removeRow(0)
        self.arg_widgets.clear()

        # build form
        for arg in tool.args:
            # hide internal help-only args? keep all
            w = ArgWidget(arg)
            label = arg.display_name
            if arg.required:
                label = f"{label} *"
            lab = QLabel(label)
            if arg.help:
                lab.setToolTip(arg.help)
                w.setToolTip(arg.help)
            self.form_layout.addRow(lab, w)
            self.arg_widgets[arg.dest] = w

        # load preset (if exists)
        self._load_preset(silent=True)
        self._update_preview()

    # ----- commands -----
    def _collect_args(self) -> Dict[str, Any]:
        data: Dict[str, Any] = {}
        for dest, w in self.arg_widgets.items():
            data[dest] = w.value()
        return data

    def _validate(self) -> Optional[str]:
        if not self.current_tool:
            return "No tool selected."
        # required fields
        for arg in self.current_tool.args:
            if not arg.required:
                continue
            w = self.arg_widgets.get(arg.dest)
            if not w:
                continue
            v = w.value()
            action = (arg.action or "").lower()
            if action in ("store_true", "store_false"):
                continue
            if v is None or (isinstance(v, str) and v.strip() == ""):
                return f"Missing required argument: {arg.display_name}"
        return None

    def build_command(self) -> List[str]:
        assert self.current_tool is not None
        pyexe = self.python_edit.text().strip() or sys.executable
        script = str(self.current_tool.script_path)

        argv: List[str] = [pyexe, script]

        for arg in self.current_tool.args:
            w = self.arg_widgets.get(arg.dest)
            if not w:
                continue
            v = w.value()
            action = (arg.action or "").lower()

            if action == "store_true":
                if bool(v):
                    argv.append(arg.long_flag or arg.display_name)
                continue
            if action == "store_false":
                # include flag if user wants False (rare)
                if (not bool(v)):
                    argv.append(arg.long_flag or arg.display_name)
                continue

            if arg.is_positional:
                if isinstance(v, str) and v.strip():
                    # split by whitespace (allows multiple inputs)
                    argv.extend(shlex.split(v))
                continue

            flag = arg.long_flag or arg.display_name
            if isinstance(v, str):
                if v.strip() == "":
                    continue
                argv.extend([flag, v])
            else:
                # numeric/choice
                if v is None:
                    continue
                argv.extend([flag, str(v)])

        return argv

    def _update_preview(self):
        if not self.current_tool:
            self.cmd_preview.setText("")
            return
        err = self._validate()
        argv = self.build_command() if err is None else []
        cmd = " ".join(shlex.quote(x) for x in argv) if argv else ""
        if err:
            cmd = f"[Invalid] {err}"
        self.cmd_preview.setText(cmd)

    # ----- run process -----
    def _run(self):
        if self.proc and self.proc.state() != QProcess.NotRunning:
            QMessageBox.warning(self, "Running", "A process is already running.")
            return
        if not self.current_tool:
            return
        err = self._validate()
        if err:
            QMessageBox.warning(self, "Missing arguments", err)
            return

        argv = self.build_command()
        pyexe = argv[0]
        args = argv[1:]

        self.log.append(f"$ {' '.join(shlex.quote(x) for x in argv)}\n")

        self.proc = QProcess(self)
        self.proc.setProgram(pyexe)
        self.proc.setArguments(args)

        cwd = self.cwd_edit.text().strip() or os.getcwd()
        self.proc.setWorkingDirectory(cwd)

        self.proc.readyReadStandardOutput.connect(self._on_stdout)
        self.proc.readyReadStandardError.connect(self._on_stderr)
        self.proc.finished.connect(self._on_finished)

        self.btn_run.setEnabled(False)
        self.btn_stop.setEnabled(True)

        self.proc.start()

        if not self.proc.waitForStarted(5000):
            QMessageBox.critical(self, "Failed to start", "Could not start the process.")
            self.btn_run.setEnabled(True)
            self.btn_stop.setEnabled(False)

    def _stop(self):
        if self.proc and self.proc.state() != QProcess.NotRunning:
            self.proc.kill()
            self.log.append("\n[INFO] Process killed by user.\n")

    def _on_stdout(self):
        if not self.proc:
            return
        data = self.proc.readAllStandardOutput().data().decode("utf-8", errors="ignore")
        if data:
            self.log.moveCursor(self.log.textCursor().End)
            self.log.insertPlainText(data)

    def _on_stderr(self):
        if not self.proc:
            return
        data = self.proc.readAllStandardError().data().decode("utf-8", errors="ignore")
        if data:
            self.log.moveCursor(self.log.textCursor().End)
            self.log.insertPlainText(data)

    def _on_finished(self, exit_code: int, exit_status):
        self.log.append(f"\n[DONE] exit_code={exit_code}\n")
        self.btn_run.setEnabled(True)
        self.btn_stop.setEnabled(False)

    # ----- presets -----
    def _load_preset(self, silent: bool = False):
        if not self.current_tool:
            return
        p = preset_path(self.presets_dir, self.current_tool.id)
        data = load_preset(p)
        if not data:
            if not silent:
                QMessageBox.information(self, "Preset", "No preset found for this tool.")
            return
        for k, v in data.items():
            w = self.arg_widgets.get(k)
            if w:
                w.set_value(v)
        self._update_preview()
        if not silent:
            QMessageBox.information(self, "Preset", f"Loaded preset: {p.name}")

    def _save_preset(self):
        if not self.current_tool:
            return
        data = self._collect_args()
        p = preset_path(self.presets_dir, self.current_tool.id)
        save_preset(p, data)
        QMessageBox.information(self, "Preset", f"Saved preset: {p.name}")

    # ----- misc -----
    def _browse_python(self):
        f, _ = QFileDialog.getOpenFileName(self, "Select Python executable", os.getcwd(), "All files (*.*)")
        if f:
            self.python_edit.setText(f)
            self._update_preview()

    def _browse_cwd(self):
        d = QFileDialog.getExistingDirectory(self, "Select working directory", os.getcwd())
        if d:
            self.cwd_edit.setText(d)

    def _open_manual(self):
        if not self.current_tool or not self.current_tool.docs_path:
            return
        txt = self.current_tool.docs_path.read_text(encoding="utf-8", errors="ignore")
        dlg = QMessageBox(self)
        dlg.setWindowTitle(f"Manual — {self.current_tool.id}")
        dlg.setTextFormat(Qt.PlainText)
        dlg.setText(txt[:60000])  # prevent huge dialogs
        dlg.exec()

    def _open_logs_folder(self):
        # cross-platform open folder
        path = str(self.logs_dir.resolve())
        if sys.platform.startswith("darwin"):
            os.system(f"open {shlex.quote(path)}")
        elif os.name == "nt":
            os.system(f"explorer {shlex.quote(path)}")
        else:
            os.system(f"xdg-open {shlex.quote(path)}")

    def _about(self):
        QMessageBox.information(
            self,
            "About",
            "OmicsCanvas GUI\n\n"
            "A PySide6 desktop wrapper for the OmicsCanvas/BamTrackSuite CLI tools.\n"
            "It builds parameter forms by statically parsing argparse definitions (AST), so it does not import your scripts.",
        )


def main(argv=None):
    """Classic (non-Fluent) UI entrypoint."""
    root_dir = Path(__file__).resolve().parent
    if argv is not None:
        sys.argv = list(argv)
    app = QApplication(sys.argv)
    win = MainWindow(root_dir)
    win.show()
    sys.exit(app.exec())
