# Home tile images (optional)

You can replace the default icons with your own images.

## Where to put images
Put PNG/SVG/WebP files here:
- `omicscanvas_gui/assets/home/`

## Naming rules (any one works)
### By tool id
- `tool_05.png`
- `tool_10.svg`
- `tool_15.webp`

### By route/object name (slug)
- `tool_05_compute_bam_to_gene_matrices.png` (slugged forms)

### By category
- `cat_prepare.svg`
- `cat_plot.png`

If an image is found, the Home page tile will show it; otherwise it falls back to a Fluent icon.
