# 19_omicscanvas_go_enrich.py — GO Enrichment + Bubble Plot

This script performs **GO enrichment** using a **hypergeometric right‑tail test**, applies **Benjamini–Hochberg FDR**, and produces a **bubble scatter plot** (seaborn).

- Statistics: `p = P(X >= k),  X ~ Hypergeom(N, K, n)`- Multiple testing: BH‑FDR (q‑value)---

## 1) What it does

Given a query gene list and a GO annotation table:

1. Builds a GO‑annotated background (either **all annotated genes** or a user‑provided background list).
2. For each GO term:
   - `N`: number of background genes
   - `n`: number of query genes intersecting the background
   - `K`: number of background genes annotated with the term
   - `k`: number of query genes annotated with the term3. Computes hypergeometric **right‑tail** p‑values (`sf(k-1, N, K, n)`).
4. Adjusts p‑values to **FDR** using BH.5. Writes enrichment tables and draws bubble plots (Top‑N terms).---

## 2) Requirements

Python packages:

- `numpy`
- `pandas`
- `scipy`
- `matplotlib`
- `seaborn`Install (pip):

```bash
pip install numpy pandas scipy matplotlib seaborn
```

---

## 3) Inputs

### 3.1 Query gene list (`--genes`) — required

Plain text, **one gene ID per line**. Empty lines and `#` comment lines are ignored.Example:

```
GeneA
GeneB
GeneC
```

The script de‑duplicates genes while preserving the original order.### 3.2 GO annotation table (`--go-annot`) — required

Tab‑separated text with **at least 4 columns**:

```
gene_id<TAB>GO_ID<TAB>Description<TAB>Ontology
```

Ontology must be one of:
- `biological_process`
- `molecular_function`
- `cellular_component`Notes on parsing:
- Extra columns are allowed; only the first 4 columns are used.- Header row is optional; the script tries to detect and drop it automatically.- Lines starting with `#` are treated as comments.

### 3.3 Optional background gene list (`--background`)

If provided, background genes are `background_list ∩ (GO‑annotated genes)`.If omitted, background is **all genes present in GO annotations**.Format: same as `--genes` (one gene per line).

---

## 4) Default filters

By default, the script **removes**:

- GO “root” terms: `GO:0008150`, `GO:0003674`, `GO:0005575`- Terms with Description containing the word `obsolete` (case‑insensitive).Override:
- `--keep-root` keeps root terms.- `--keep-obsolete` keeps “obsolete” terms.---

## 5) Outputs

### 5.1 Enrichment table (TSV)

For each run, the script writes:

- `<out_prefix>.<tag>.go_enrichment.tsv`Where `<tag>` is:
- `bp`, `cc`, `mf` when `--three-ontologies`- otherwise: `all` or the selected ontology name (`biological_process`, …)Columns include (core):
- `GO_ID`, `Description`, `Ontology`
- `k`, `n`, `K`, `N`, `GeneRatio`, `BgRatio`
- `pvalue`, `FDR`
- `geneIDs` (query genes hitting the term; `;`‑joined)### 5.2 Bubble plot

If the enrichment result is non‑empty, the script also writes:

- `<out_prefix>.<tag>.go_bubbleplot.<pdf|png>`Bubble plot encoding:
- **Y**: GO term Description (top terms)
- **X**: significance (`-log10(FDR)` or `-log10(pvalue)` by default)
- **Point size**: `GeneRatio`
- **Color**: `Ontology`Legend is placed outside the axes; output is saved at `dpi=300`.If no enriched terms pass filters, the plot is **not** generated.---

## 6) Usage examples

### 6.1 Run BP/CC/MF separately (3 tables + 3 plots)

```bash
python 19_omicscanvas_go_enrich.py   --genes fig1_cluster_1_genes.txt   --go-annot test_GO.txt   --out-prefix cluster1   --three-ontologies   --top 30 --metric fdr --plot-format pdf
```
(Example mirrors the script header.)### 6.2 Run a single ontology only

```bash
python 19_omicscanvas_go_enrich.py   --genes fig1_cluster_1_genes.txt   --go-annot test_GO.txt   --out-prefix cluster1   --ontology biological_process   --top 30 --metric fdr
```
(Example mirrors the script header.)### 6.3 Use a custom background gene set

```bash
python 19_omicscanvas_go_enrich.py   --genes DEG_up.txt   --background all_detected_genes.txt   --go-annot go_annot.tsv   --out-prefix DEG_up.bg_detected   --ontology all   --top 30 --metric fdr
```

### 6.4 Plot by pvalue and do not transform X

```bash
python 19_omicscanvas_go_enrich.py   --genes DEG_up.txt   --go-annot go_annot.tsv   --out-prefix DEG_up.pvalue_raw   --metric pvalue   --x-transform none   --plot-format png
```

### 6.5 Keep root terms / obsolete terms

```bash
python 19_omicscanvas_go_enrich.py   --genes DEG_up.txt   --go-annot go_annot.tsv   --out-prefix DEG_up.keep_root   --keep-root --keep-obsolete   --ontology biological_process
```

---

## 7) Arguments

Required:
- `--genes` : query gene list file- `--go-annot` : GO annotation TSV (>=4 columns)- `--out-prefix` : output prefixOntology selection:
- `--three-ontologies` : run BP/CC/MF separately (ignores `--ontology`)- `--ontology {all, biological_process, molecular_function, cellular_component}` (default `all`)Background and filters:
- `--background` : optional background gene list (default: all GO‑annotated genes)- `--min-k` (default `2`) : minimum overlap genes (`k`) for a term to be kept- `--keep-root` : keep root terms- `--keep-obsolete` : keep “obsolete” termsPlot settings:
- `--top` (default `30`) : top terms to show- `--metric {pvalue,fdr}` (default `fdr`) : x-axis significance metric- `--x-transform {neglog10,none}` (default `neglog10`) : x-axis transform- `--plot-format {pdf,png}` (default `pdf`) : plot output format---

## 8) Troubleshooting

### “None of the query genes are in the GO-annotated background”
Your query gene IDs do not overlap with GO‑annotated gene IDs (or with your `--background` after intersecting).Check:
- gene ID versioning (e.g., `.1` suffix vs not)
- whether your GO annotation uses the same ID system as your gene list

### “Background gene set is empty…”
Your `--background` has no overlap with GO‑annotated genes.Fix by using a compatible background list, or omit `--background`.

### No plot generated
If all terms are filtered out (e.g., `--min-k` too high, or few genes), the enrichment table may be empty and the script will skip plotting.Try:
- decreasing `--min-k`
- increasing `--top`
- ensuring enough query genes are annotated

---

## 9) CLI help

```bash
python 19_omicscanvas_go_enrich.py -h
```
