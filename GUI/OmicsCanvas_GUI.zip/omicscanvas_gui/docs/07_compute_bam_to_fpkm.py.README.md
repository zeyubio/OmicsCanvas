# 07_compute_bam_to_fpkm.py

OmicsCanvas utility — compute **strict FPKM / TPM** from a **coordinate-sorted + indexed BAM** using `pysam`.

This script is meant to work *after* Step 1 (GFF3 → BED + length table):

- BED intervals (at least 4 columns): `chrom  start  end  gene_id`
- Length table (2 columns, no header): `gene_id<TAB>length_bp`It then counts reads (SE) or fragments (PE) per interval under strict filters, and outputs:

`FPKM, TPM, counts, length_bp`---

## 1) What “strict” means in this script

### 1.1 Read-level filters (default strict)
A read is kept only if it is: mapped, not secondary, not supplementary, not duplicate (unless enabled), not QC-fail (unless enabled), and `MAPQ >= --min-mapq`.Options:
- `--min-mapq INT` (default 0)- `--include-duplicates` (default: exclude duplicates)- `--include-qcfail` (default: exclude QC-fail)### 1.2 Paired-end mode counts FRAGMENTS
In PE mode:
- **Library size** is counted as the number of fragments by counting only `read1` (one per template).- **Interval counts** are fragments deduplicated by `query_name` within each interval (so a fragment is counted once even if both mates overlap).Proper-pair strictness:
- By default, PE mode requires **proper pairs** and both mates mapped.- To allow improper pairs, use `--allow-improper-pair` (this disables the proper-pair requirement).> Note: if intervals overlap, the same fragment can be counted for multiple intervals (this is standard “overlap counting” behavior).

---

## 2) Coordinate conventions

- BED is expected to be **0-based, end-exclusive** (standard BED).- If your “BED” is actually **1-based inclusive**, enable:
  - `--bed-one-based`
  The script converts `[st, en]` → `[st-1, en)` (end unchanged).---

## 3) Output

`--out` writes a TSV with:

- index: `gene_id`
- columns: `FPKM`, `TPM`, `counts`, `length_bp`Formulas:
- `FPKM = 1e9 * counts / (length_bp * N)` where `N` is strict library size after filtering- `TPM` is computed from `RPK = counts / (length_bp/1000)` and scaled to 1e6---

## 4) Requirements

- Python ≥ 3.8
- `pandas`
- `pysam` (required at runtime; imported lazily so `-h` still works without it)Install:
```bash
pip install pandas pysam
```

---

## 5) Usage

### 5.1 Single-end (SE)
```bash
python 07_compute_bam_to_fpkm.py \
  -b genes.bed \
  -l gene_len.tsv \
  -m sample.bam \
  -o sample.fpkm_tpm.tsv \
  --mode se \
  --min-mapq 10
```

### 5.2 Paired-end (PE, strict proper pairs; default behavior)
```bash
python 07_compute_bam_to_fpkm.py \
  -b genes.bed \
  -l gene_len.tsv \
  -m sample.bam \
  -o sample.fpkm_tpm.tsv \
  --mode pe \
  --min-mapq 10
```

### 5.3 Paired-end but allow improper pairs
```bash
python 07_compute_bam_to_fpkm.py \
  -b genes.bed \
  -l gene_len.tsv \
  -m sample.bam \
  -o sample.fpkm_tpm.tsv \
  --mode pe \
  --allow-improper-pair
```

### 5.4 Auto-detect SE/PE (default)
```bash
python 07_compute_bam_to_fpkm.py \
  -b genes.bed \
  -l gene_len.tsv \
  -m sample.bam \
  -o sample.fpkm_tpm.tsv
```
Mode auto-detection inspects up to 200 mapped reads and chooses `pe` if any is paired.---

## 6) Command-line arguments (complete)

Required:
- `-b/--bed` : BED with ≥4 columns (chrom, start, end, gene_id)- `-l/--length` : length table (gene_id, length_bp)- `-m/--bam` : BAM (sorted + indexed)- `-o/--out` : output TSVMode:
- `--mode {auto,se,pe}` (default: `auto`)Filtering:
- `--min-mapq INT` (default 0)- `--include-duplicates`- `--include-qcfail`Paired-end strictness:
- `--require-proper-pair` (present in CLI; effectively enabled by default)- `--allow-improper-pair` (disables the proper-pair requirement)Coordinate conversion:
- `--bed-one-based` : convert 1-based inclusive BED to standard BEDPerformance / logging:
- `--threads INT` (default 1) : threads for BAM BGZF decompression in pysam- `--progress INT` (default 1000) : print progress every N intervals (0 disables)---

## 7) Troubleshooting

### “BAM index not found or invalid”
The script requires a `.bai` and will raise an error if missing.Fix:
```bash
samtools index sample.bam
```

### “pysam is required”
Install:
```bash
pip install pysam
```
(raised by the script)### “Library size N <= 0 after filtering”
Your filters removed all reads/fragments. Lower `--min-mapq`, or allow duplicates/QC-fail if appropriate.### “Sum of RPK <= 0”
All counts are zero after filtering (or lengths are invalid). Check input files and filters.---

## 8) Help
```bash
python 07_compute_bam_to_fpkm.py -h
```

(Help header may show `prog=omicscanvas_bam_to_fpkm.py`, but you can always run the repo script by filename.)