# 12_plot_histone_vs_expr_heatmap.py

Plot **track matrix heatmaps** (ChIP-seq/ATAC-seq, etc.) **binned by RNA expression**.

This tool is designed to consume the **matrix outputs from script 05** (`05_compute_bam_to_gene_matrices.py`), i.e.:
- `*_tss_matrix.tsv`
- `*_gene_profile_matrix.tsv`
- `*_tes_matrix.tsv`

---

## 1) Inputs

- A directory containing gene-centric matrices produced by script **05**.
- An expression table (counts/FPKM/TPM) with gene IDs as row names or a gene ID column.

---

## 2) Outputs

- Heatmap figure(s) (PDF/PNG/SVG depending on your arguments)
- A binned summary matrix (optional, if enabled by script options)

---

## 3) Typical workflow

- Use script **07** to generate expression quantification (FPKM/TPM) if you do not already have expression.
- Use script **05** to generate TSS/gene/TES matrices for each track (ChIP/ATAC/RNA BAM).
- Use this script to group genes by expression bins, then plot heatmaps per track.

---

## 4) Notes

- The script supports multiple tracks and replicate averaging via the `--tracks` syntax described in the script header.
- If your matrix suffixes are legacy, override them with `--suffix-tss/--suffix-gene/--suffix-tes`.

---

## 5) CLI help

```bash
python 12_plot_histone_vs_expr_heatmap.py -h
```
