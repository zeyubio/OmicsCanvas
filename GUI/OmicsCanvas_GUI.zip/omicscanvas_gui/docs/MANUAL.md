# OmicsCanvas GUI Manual

This manual explains how to use the **OmicsCanvas desktop GUI** to run the 19 OmicsCanvas scripts, manage presets, and build end‑to‑end multi‑omics workflows.

---

## 1) Concepts

### 1.1 Models vs Tools
- **Models** are high-level workflows (Data Prepare, Calculate Matrix, RNA Analysis, Methylation Analysis, Heatmap & Clustering, Circos Plot, ChIP-seq Analysis).
- **Tools** are the concrete scripts (`01`–`19`). The GUI builds parameter forms from each script’s `argparse` options.

### 1.2 Output-first usage
Most tools write files to an output folder you specify. A common pattern is:
- run one tool → produce intermediate matrices/TSV
- feed those outputs into a plotting or downstream analysis tool

---

## 2) Install and run

### 2.1 Install dependencies
```bash
pip install -r requirements.txt
```

### 2.2 Start the GUI
```bash
python -m omicscanvas_gui
```

---

## 3) Quick tutorial

### 3.1 Run a tool (GUI workflow)
- Open **Home**.
- In **Models** (top), click a model card (e.g., *Data Prepare*).
- Pick a tool from the list (e.g., *Prepare GFF3 → BED + gene length table*).
- Fill parameters in the right panel (use the folder/file picker buttons when available).
- Click **Run**.
- Watch logs in the **Console** area.
- Use **Open Output** (or open the output directory) to check generated files.

### 3.2 Save and reuse presets
- After setting parameters, click **Save Preset**.
- Next time, use **Load Preset** to restore the same parameter set.

### 3.3 Where outputs go
- Prefer a project structure like:
  - `results/prepare/`
  - `results/matrix/`
  - `results/plot/`
  - `results/single_gene/`
- Keep input and output paths short (avoid spaces) if you plan to run from terminal later.

---

## 4) Recommended workflows

### 4.1 Annotation & gene BED (common prerequisite)
- Run **01** to export `gene.bed` (or transcript BED) and a gene length table.
- The BED and length table are used by matrix generation tools.

### 4.2 BAM → gene-centric matrices → profiles/heatmaps
- Run **05** to compute matrices (`*_tss_matrix.tsv`, `*_gene_profile_matrix.tsv`, `*_tes_matrix.tsv`) from BAM tracks.
- Optional: run **07** to compute expression (counts/FPKM/TPM).
- Plot:
  - **11**: whole profile plots (2D/3D)
  - **12**: track vs expression heatmap (expression-binned)
  - **13**: clustering heatmaps

### 4.3 WGBS/Nanopore CX methylation workflow
- Run **02** to split CX by context (CG/CHG/CHH) if needed.
- Run **03** to merge replicates.
- Run **04** to extract gene methylation summaries.
- Run **06** to convert CX into methylation matrices.
- Plot/analysis:
  - **15** methylation profile (2D/3D)
  - **16** methylation vs expression heatmap
  - **14** methylation bin correlation triangle

### 4.4 Single-gene visualization with peaks
- **17**: single-gene 2D/3D track plots with MACS2 peaks shading
- **18**: single-gene circle plot with peaks

### 4.5 Genome-wide summary
- **10**: genome-wide circos plot

### 4.6 RNA / DE and enrichment
- **08**: negative-binomial DE
- **09**: merge expression + pairwise DE
- **19**: GO enrichment (bubble plots)

---

## 5) Tool manuals (per script)

### 5.1 Data Prepare
- [01_prepare_gff_to_bed_genes_length](01_prepare_gff_to_bed_genes_length.README.md)
- [02_prepare_cx_context_split](02_prepare_cx_context_split.py.README.md)
- [03_prepare_cx_replicate_merge](03_prepare_cx_replicate_merge.README.md)
- [04_extract_gene_methylation](4OmicsCanvas_Extract_Gene_Methylation_EN.updated.md)

### 5.2 Calculate Matrix
- [05_bam_to_gene_matrices](5OmicsCanvas_Step2_BAM_to_Matrices_EN.updated.md)
- [06_cx_gene_matrix](06_compute_cx_gene_matrix.py.README.md)
- [07_bam_to_fpkm](07_compute_bam_to_fpkm.py.README.md)

### 5.3 RNA Analysis
- [08_nb_de](08_compute_nb_de.py.README.md)
- [09_merge_expr_pairwise_de](09_compute_merge_expr_pairwise_de.py.README.md)
- [19_go_enrich](19_omicscanvas_go_enrich.README.md)

### 5.4 Heatmap & Clustering
- [12_histone_vs_expr_heatmap](12_plot_histone_vs_expr_heatmap.README.md)
- [13_histone_cluster_pipeline](13OmicsCanvas_Histone_Cluster_Pipeline_EN.updated.md)

### 5.5 Methylation Analysis
- [14_methylation_bin_correlation_triangle](14OmicsCanvas_Methylation_Bin_Correlation_Triangle_EN.md)
- [15_methylation_profile_2d3d](15_plot_methylation_profile_2d3d.README.md)
- [16_meth_vs_expr_heatmap](16_plot_meth_vs_expr_heatmap.README.md)

### 5.6 ChIP-seq Analysis
- [11_whole_profile_2d3d](11OmicsCanvas_Step3_Plot_Profiles_2D3D_EN.updated.md)
- [17_gene_tracks_2d3d_peaks](17_plot_gene_tracks_2d3d_peaks.README.md)

### 5.7 Circos Plot
- [10_plot_genome_circos](10_plot_genome_circos_Readme.updated.md)

### 5.8 Single-gene
- [18_gene_circle_plot_peaks](18_plot_gene_circle_plot_peaks.README.updated.md)
