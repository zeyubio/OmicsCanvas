from __future__ import annotations

import os
import sys
import shlex
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional, List, Tuple

from PySide6.QtCore import Qt, QProcess, QSize
from PySide6.QtGui import QFont, QIcon, QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QWidget,
    QLabel,
    QGridLayout,
    QVBoxLayout,
    QHBoxLayout,
    QFormLayout,
    QFileDialog,
    QScrollArea,
    QSizePolicy,
)

# PySide6-Fluent-Widgets exposes the `qfluentwidgets` import name.
# (Do not install multiple *-Fluent-Widgets packages simultaneously.)
from qfluentwidgets import (  # type: ignore
    FluentWindow,
    NavigationItemPosition,
    FluentIcon as FIF,
    setTheme,
    Theme,
    setThemeColor,
    isDarkTheme,
    TitleLabel,
    SubtitleLabel,
    BodyLabel,
    CaptionLabel,
    CardWidget,
    LineEdit,
    SearchLineEdit,
    PlainTextEdit,
    ComboBox,
    CheckBox,
    SwitchButton,
    SpinBox,
    DoubleSpinBox,
    PushButton,
    PrimaryPushButton,
    ToolButton,
    InfoBar,
    InfoBarPosition,
)

from .tooling import discover_tools, ToolSpec, ArgumentSpec, preset_path, load_preset, save_preset


# -------------------------
# Helpers
# -------------------------

def _slug(s: str) -> str:
    out = []
    for ch in s.lower():
        if ch.isalnum():
            out.append(ch)
        else:
            out.append('_')
    # collapse
    x = ''.join(out)
    while '__' in x:
        x = x.replace('__', '_')
    return x.strip('_') or 'x'


def guess_is_path_arg(arg: ArgumentSpec) -> bool:
    key = (arg.display_name + " " + (arg.help or "")).lower()
    tokens = [
        "file", "path", "dir", "folder", "bam", "bed", "gff", "gtf", "fasta", "fastq",
        "out", "prefix", "matrix", "genome", "annotation", "peak", "narrowpeak"
    ]
    return any(t in key for t in tokens)


def guess_is_dir_arg(arg: ArgumentSpec) -> bool:
    key = (arg.display_name + " " + (arg.help or "")).lower()
    return ("dir" in key) or ("folder" in key) or ("outdir" in key)


def classify_arg_group(arg: ArgumentSpec) -> str:
    """Heuristic grouping for nicer UI."""
    name = (arg.dest or "").lower()
    text = (arg.display_name + " " + (arg.help or "")).lower()

    # Output
    if any(k in name for k in ["out", "output", "prefix", "save", "pdf", "png", "svg", "eps"]):
        return "Output"
    if any(k in text for k in ["outdir", "output", "save to", "prefix", "export"]):
        return "Output"

    # Input paths
    if guess_is_path_arg(arg) or any(k in text for k in ["input", "reads", "bam", "bed", "gff", "gtf", "fasta", "matrix"]):
        return "Input"

    # Plot / style
    if any(k in name for k in ["fig", "width", "height", "dpi", "cmap", "color", "palette", "ylim", "vmin", "vmax", "alpha"]):
        return "Plot"
    if any(k in text for k in ["figure", "plot", "color", "palette", "cmap", "dpi", "ylim", "vmin", "vmax"]):
        return "Plot"

    # Performance / advanced
    if any(k in name for k in ["thread", "cpu", "gpu", "seed", "chunk", "batch", "max", "min", "window"]):
        return "Advanced"

    return "Parameters"


def group_args(args: List[ArgumentSpec]) -> List[Tuple[str, List[ArgumentSpec]]]:
    buckets: Dict[str, List[ArgumentSpec]] = {"Input": [], "Parameters": [], "Plot": [], "Output": [], "Advanced": []}
    for a in args:
        g = classify_arg_group(a)
        if g not in buckets:
            buckets[g] = []
        buckets[g].append(a)

    # Keep stable order and drop empties
    ordered = [(k, buckets[k]) for k in ["Input", "Parameters", "Plot", "Output", "Advanced"] if buckets.get(k)]
    # any extra groups
    for k, v in buckets.items():
        if k not in {"Input", "Parameters", "Plot", "Output", "Advanced"} and v:
            ordered.append((k, v))
    return ordered


# -------------------------
# Fluent arg row widget
# -------------------------

class FluentArgWidget(QWidget):
    """A single argument editor (fluent controls + optional browse button)."""

    def __init__(self, arg: ArgumentSpec, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.arg = arg

        self._widget: QWidget
        self._browse: Optional[ToolButton] = None

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)

        action = (arg.action or "").lower()
        tname = (arg.type_name or "").lower()
        choices = arg.choices

        if action in ("store_true", "store_false"):
            # Switch looks more modern than a checkbox for on/off
            w = SwitchButton("", self)
            default = bool(arg.default) if arg.default is not None else (action == "store_false")
            w.setChecked(default)
            self._widget = w
            layout.addWidget(w)
        elif choices:
            w = ComboBox(self)
            for c in choices:
                w.addItem(str(c))
            if arg.default is not None:
                w.setCurrentText(str(arg.default))
            self._widget = w
            layout.addWidget(w, 1)
        elif tname == "int":
            w = SpinBox(self)
            # NOTE: Qt spin boxes are 32-bit signed int. Using wider ranges
            # triggers libshiboken overflow on some platforms.
            w.setRange(-(2**31), 2**31 - 1)
            if arg.default is not None:
                try:
                    w.setValue(int(arg.default))
                except Exception:
                    pass
            self._widget = w
            layout.addWidget(w)
        elif tname == "float":
            w = DoubleSpinBox(self)
            w.setDecimals(6)
            w.setRange(-1e18, 1e18)
            if arg.default is not None:
                try:
                    w.setValue(float(arg.default))
                except Exception:
                    pass
            self._widget = w
            layout.addWidget(w)
        else:
            w = LineEdit(self)
            if arg.default not in (None, False):
                w.setText(str(arg.default))
            if arg.help:
                w.setPlaceholderText(arg.help[:90].replace("\n", " "))
            self._widget = w
            layout.addWidget(w, 1)

            if guess_is_path_arg(arg):
                b = ToolButton(FIF.FOLDER, self)
                b.setToolTip("Browse")
                b.clicked.connect(self._browse_clicked)
                self._browse = b
                layout.addWidget(b)

        self.setLayout(layout)

    def _browse_clicked(self):
        if guess_is_dir_arg(self.arg):
            d = QFileDialog.getExistingDirectory(self, "Select directory", os.getcwd())
            if d:
                self.set_value(d)
        else:
            f, _ = QFileDialog.getOpenFileName(self, "Select file", os.getcwd(), "All files (*.*)")
            if f:
                self.set_value(f)

    def value(self) -> Any:
        if isinstance(self._widget, SwitchButton):
            return self._widget.isChecked()
        if isinstance(self._widget, CheckBox):
            return self._widget.isChecked()
        if isinstance(self._widget, ComboBox):
            return self._widget.currentText()
        if isinstance(self._widget, SpinBox):
            return int(self._widget.value())
        if isinstance(self._widget, DoubleSpinBox):
            return float(self._widget.value())
        if isinstance(self._widget, LineEdit):
            return self._widget.text().strip()
        return None

    def set_value(self, v: Any) -> None:
        if isinstance(self._widget, SwitchButton):
            self._widget.setChecked(bool(v))
        elif isinstance(self._widget, CheckBox):
            self._widget.setChecked(bool(v))
        elif isinstance(self._widget, ComboBox):
            self._widget.setCurrentText(str(v))
        elif isinstance(self._widget, SpinBox):
            try:
                self._widget.setValue(int(v))
            except Exception:
                pass
        elif isinstance(self._widget, DoubleSpinBox):
            try:
                self._widget.setValue(float(v))
            except Exception:
                pass
        elif isinstance(self._widget, LineEdit):
            self._widget.setText("" if v is None else str(v))


# -------------------------
# Interfaces
# -------------------------


class HomeTile(CardWidget):
    """Clickable tile used on Home page."""

    def __init__(
        self,
        title: str,
        subtitle: str,
        icon: Optional[QIcon] = None,
        image_path: Optional[Path] = None,
        on_click=None,
        parent=None,
        *,
        art_height: int = 86,
        min_width: int = 260,
        min_height: int = 150,
    ):
        super().__init__(parent)
        self._on_click = on_click
        self.setCursor(Qt.PointingHandCursor)

        self.setMinimumWidth(int(min_width))
        self.setMinimumHeight(int(min_height))

        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 14, 16, 14)
        lay.setSpacing(8)

        # icon/image
        self.art = QLabel(self)
        self.art.setFixedHeight(int(art_height))
        self.art.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)

        pm: Optional[QPixmap] = None
        if image_path is not None and image_path.exists():
            # Render as a small banner (prefer wide aspect). QIcon supports SVG/PNG/WebP.
            try:
                # request a larger source pixmap to keep PNG/SVG crisp
                pm = QIcon(str(image_path)).pixmap(QSize(1200, 380))
                if pm is not None and not pm.isNull():
                    pm = pm.scaledToHeight(int(art_height), Qt.SmoothTransformation)
            except Exception:
                pm = None
        elif icon is not None:
            pm = icon.pixmap(QSize(56, 56))

        if pm is not None and not pm.isNull():
            self.art.setPixmap(pm)
        lay.addWidget(self.art)

        self.title = BodyLabel(title, self)
        f = self.title.font()
        f.setBold(True)
        self.title.setFont(f)
        lay.addWidget(self.title)

        self.subtitle = CaptionLabel(subtitle, self)
        self.subtitle.setWordWrap(True)
        lay.addWidget(self.subtitle)

        lay.addStretch(1)

    def mousePressEvent(self, e):  # noqa: N802
        super().mousePressEvent(e)
        if callable(self._on_click):
            self._on_click()




# -------------------------
# Home models (custom tiles)
# -------------------------
# NOTE: these "models" are curated entry points (banner + a small group of scripts).
#       They are independent of the default categories.
MODELS = [
    {"name": "Data Prepare",         "image": "DataPrepare.png",         "tool_ids": ["01", "02", "03", "04"]},
    {"name": "Calculate Matrix",     "image": "CalculateMatrix.png",     "tool_ids": ["05", "06", "07"]},
    {"name": "RNA Analysis",         "image": "RNAAnalysis.png",         "tool_ids": ["08", "09", "19"]},
    {"name": "Methylation Analysis", "image": "MethyltionAnalysis.png",  "tool_ids": ["14", "15", "16"]},
    {"name": "Heatmap & Clustering", "image": "Heatmap&Clustering.png",  "tool_ids": ["12", "13"]},
    {"name": "Circos Plot",          "image": "CircosPlot.png",          "tool_ids": ["10", "18"]},
    {"name": "ChIP-seq Analysis",    "image": "ChipseqAnalysis.png",     "tool_ids": ["11", "17"]},
]

# keep for backward compatibility; disabled per latest UI layout
OTHER_MODELS: list[dict] = []
class HomeInterface(QWidget):
    def __init__(self, win: 'FluentMainWindow', parent=None):
        super().__init__(parent)
        self.win = win
        self.setObjectName("home")

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        body = QWidget()
        scroll.setWidget(body)
        outer.addWidget(scroll)

        layout = QVBoxLayout(body)
        layout.setContentsMargins(28, 22, 28, 28)
        layout.setSpacing(16)

        # -------- Hero --------
        hero = CardWidget(self)
        hero.setObjectName("homeHero")
        hero_l = QVBoxLayout(hero)
        hero_l.setContentsMargins(22, 20, 22, 18)
        hero_l.setSpacing(10)

        title = TitleLabel("OmicsCanvas", hero)
        subtitle = SubtitleLabel("Fluent GUI • One-click access to 1–19 tools", hero)
        subtitle.setTextColor("#6b6b6b" if not isDarkTheme() else "#bdbdbd", "#bdbdbd")

        hero_l.addWidget(title)
        hero_l.addWidget(subtitle)

        # Search + quick actions row
        row = QWidget(hero)
        row_l = QHBoxLayout(row)
        row_l.setContentsMargins(0, 0, 0, 0)
        row_l.setSpacing(10)

        self.search = SearchLineEdit(row)
        self.search.setPlaceholderText("Search tool ID / name (press Enter)…")
        row_l.addWidget(self.search, 1)

        self.btnDocs = PushButton("Docs", row)
        self.btnDocs.setIcon(FIF.HELP.icon())
        row_l.addWidget(self.btnDocs)

        self.btnOpenLogs = PushButton("Open Logs", row)
        self.btnOpenLogs.setIcon(FIF.FOLDER.icon())
        row_l.addWidget(self.btnOpenLogs)

        hero_l.addWidget(row)

        tip = CaptionLabel("Tip: You can drop your own PNG/SVG tiles into omicscanvas_gui/assets/home/ (see README).", hero)
        hero_l.addWidget(tip)

        layout.addWidget(hero)

        # Wire hero buttons
        self.search.returnPressed.connect(self.win._search_and_jump)
        self.btnOpenLogs.clicked.connect(self._open_logs_folder)
        self.btnDocs.clicked.connect(self._open_docs_folder)

        # -------- Models: curated entry points (banner cards) --------
        assets = self.win.root_dir / "assets" / "home"
        layout.addWidget(SubtitleLabel("Models", self))

        modelw = QWidget(self)
        g_models = QGridLayout(modelw)
        g_models.setContentsMargins(0, 0, 0, 0)
        g_models.setHorizontalSpacing(14)
        g_models.setVerticalSpacing(14)

        for idx, m in enumerate(MODELS):
            r = idx // 3
            c = idx % 3
            img_path = assets / m["image"]
            tile = HomeTile(
                m["name"],
                f"{len(m['tool_ids'])} tools",
                icon=FIF.APPLICATION.icon(),
                image_path=img_path if img_path.exists() else None,
                on_click=lambda mm=m: self._jump_module(mm["name"]),
                parent=self,
                art_height=128,
                min_width=340,
                min_height=210,
            )
            g_models.addWidget(tile, r, c)

        layout.addWidget(modelw)

        

# -------- Modules: every script (01–19) --------
        layout.addWidget(SubtitleLabel("Modules", self))
        modw = QWidget(self)
        mg = QGridLayout(modw)
        mg.setContentsMargins(0, 0, 0, 0)
        mg.setHorizontalSpacing(14)
        mg.setVerticalSpacing(14)

        tools_sorted = sorted(self.win.tools, key=lambda x: x.id)
        for idx, t in enumerate(tools_sorted):
            r = idx // 4
            c = idx % 4
            tile = HomeTile(
                t.title,
                t.category,
                icon=self.win.get_tool_icon(t.id),
                image_path=None,
                on_click=lambda tt=t: self._jump_tool(tt),
                parent=self,
                art_height=56,
                min_width=250,
                min_height=120,
            )
            tile.setToolTip(f"{t.id}  {t.title}\n{t.category}")
            mg.addWidget(tile, r, c)
        layout.addWidget(modw)

        

# -------- Other (less used models) --------
        if OTHER_MODELS:
            layout.addWidget(SubtitleLabel("Other", self))
            otherw = QWidget(self)
            g_other = QGridLayout(otherw)
            g_other.setContentsMargins(0, 0, 0, 0)
            g_other.setHorizontalSpacing(14)
            g_other.setVerticalSpacing(14)

            for idx, m in enumerate(OTHER_MODELS):
                r = idx // 3
                c = idx % 3
                img_path = assets / m["image"]
                tile = HomeTile(
                    m["name"],
                    f"{len(m['tool_ids'])} tools",
                    icon=FIF.APPLICATION.icon(),
                    image_path=img_path if img_path.exists() else None,
                    on_click=lambda mm=m: self._jump_module(mm["name"]),
                    parent=self,
                    art_height=128,
                    min_width=340,
                    min_height=210,
                )
                g_other.addWidget(tile, r, c)

            layout.addWidget(otherw)
        layout.addStretch(1)

        # Small style touch (hero gradient)
        self.setStyleSheet("""
        #homeHero {
            border-radius: 14px;
        }
        """)

    def _collect_categories(self) -> List[Tuple[str, List[ToolSpec]]]:
        cats: Dict[str, List[ToolSpec]] = {}
        for t in self.win.tools:
            cats.setdefault(t.category, []).append(t)
        return [(k, sorted(v, key=lambda x: x.id)) for k, v in sorted(cats.items(), key=lambda x: x[0].lower())]

    def _find_categories_by_keywords(self) -> Dict[str, Optional[str]]:
        out: Dict[str, Optional[str]] = {"prepare": None, "compute": None, "plot": None}
        cats = [c for c, _ in self._collect_categories()]
        # choose best match
        for c in cats:
            lc = c.lower()
            if out["prepare"] is None and ("prepare" in lc or "pre" in lc):
                out["prepare"] = c
            if out["compute"] is None and ("compute" in lc or "matrix" in lc or "quant" in lc):
                out["compute"] = c
            if out["plot"] is None and ("plot" in lc or "visual" in lc or "track" in lc or "heatmap" in lc):
                out["plot"] = c
        # fallback
        if out["prepare"] is None and cats:
            out["prepare"] = cats[0]
        if out["compute"] is None and len(cats) > 1:
            out["compute"] = cats[1]
        if out["plot"] is None and len(cats) > 2:
            out["plot"] = cats[2]
        return out

    def _find_tool_art(self, tool: ToolSpec) -> Optional[Path]:
        assets = self.win.root_dir / "assets" / "home"
        candidates = [
            f"tool_{tool.id}.png", f"tool_{tool.id}.svg", f"tool_{tool.id}.webp",
            f"{tool.id}.png", f"{tool.id}.svg", f"{tool.id}.webp",
            f"tool_{_slug(tool.id)}.png", f"tool_{_slug(tool.id)}.svg", f"tool_{_slug(tool.id)}.webp",
        ]
        for c in candidates:
            p = assets / c
            if p.exists():
                return p
        return None

    def _find_category_art(self, cat_name: str) -> Optional[Path]:
        assets = self.win.root_dir / "assets" / "home"
        candidates = [
            f"cat_{_slug(cat_name)}.png", f"cat_{_slug(cat_name)}.svg", f"cat_{_slug(cat_name)}.webp",
            f"{_slug(cat_name)}.png", f"{_slug(cat_name)}.svg", f"{_slug(cat_name)}.webp",
        ]
        for c in candidates:
            p = assets / c
            if p.exists():
                return p
        return None

    def _jump_tool(self, tool: ToolSpec):
        route = f"tool_{_slug(tool.id)}"
        w = self.win.findChild(QWidget, route)
        if w is None:
            InfoBar.warning(
                title="Not found",
                content=f"Could not locate UI page for tool: {tool.id}",
                orient=Qt.Horizontal,
                isClosable=True,
                position=InfoBarPosition.TOP,
                duration=2500,
                parent=self.win,
            )
            return
        self.win.switchTo(w)
        try:
            self.win.navigationInterface.setCurrentItem(route)
        except Exception:
            pass

    def _jump_category(self, cat_name: Optional[str]):
        if not cat_name:
            return
        route = f"cat_{_slug(cat_name)}"
        w = self.win.findChild(QWidget, route)
        if w is None:
            InfoBar.warning(
                title="Not found",
                content=f"Could not locate category page: {cat_name}",
                orient=Qt.Horizontal,
                isClosable=True,
                position=InfoBarPosition.TOP,
                duration=2500,
                parent=self.win,
            )
            return
        self.win.switchTo(w)
        try:
            self.win.navigationInterface.setCurrentItem(route)
        except Exception:
            pass



    def _jump_module(self, module_name: str):
        w = getattr(self.win, 'module_interfaces', {}).get(module_name)
        if w is None:
            InfoBar.warning(
                title="Not found",
                content=f"Module not found: {module_name}",
                orient=Qt.Horizontal,
                isClosable=True,
                position=InfoBarPosition.TOP,
                duration=2500,
                parent=self.win,
            )
            return
        self.win.switchTo(w)
        try:
            self.win.navigationInterface.setCurrentItem(w.objectName())
        except Exception:
            pass
    def _open_logs_folder(self):
        try:
            from PySide6.QtGui import QDesktopServices
            from PySide6.QtCore import QUrl
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.win.logs_dir)))
        except Exception:
            pass

    def _open_docs_folder(self):
        try:
            from PySide6.QtGui import QDesktopServices
            from PySide6.QtCore import QUrl
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.win.docs_dir)))
        except Exception:
            pass
class CategoryInterface(QWidget):
    def __init__(self, category_name: str, tools: List[ToolSpec], parent=None):
        super().__init__(parent)
        self.category_name = category_name
        self.tools = tools
        self.setObjectName(f"cat_{_slug(category_name)}")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 22, 28, 22)
        layout.setSpacing(14)

        layout.addWidget(TitleLabel(category_name, self))
        layout.addWidget(CaptionLabel(f"Tools in this category: {len(tools)}", self))

        card = CardWidget(self)
        cl = QVBoxLayout(card)
        cl.setContentsMargins(18, 16, 18, 16)
        cl.setSpacing(8)

        cl.addWidget(BodyLabel("Select a tool from the navigation tree", card))
        for t in tools[:8]:
            cl.addWidget(CaptionLabel(f"• {t.id}  {t.title}", card))
        if len(tools) > 8:
            cl.addWidget(CaptionLabel(f"… and {len(tools) - 8} more", card))

        layout.addWidget(card)
        layout.addStretch(1)




class ModuleInterface(QWidget):
    """A curated landing page for a module (a group of scripts)."""

    def __init__(self, win: 'FluentMainWindow', module_name: str, tool_ids: List[str], image_path: Optional[Path] = None, parent=None):
        super().__init__(parent)
        self.win = win
        self.module_name = module_name
        self.tool_ids = tool_ids
        self.setObjectName(f"module_{_slug(module_name)}")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 22, 28, 22)
        layout.setSpacing(14)

        layout.addWidget(TitleLabel(module_name, self))
        layout.addWidget(CaptionLabel("Click a card to open the corresponding tool.", self))

        if image_path is not None and image_path.exists():
            banner = CardWidget(self)
            bl = QVBoxLayout(banner)
            bl.setContentsMargins(14, 14, 14, 14)
            bl.setSpacing(8)
            lab = QLabel(banner)
            lab.setAlignment(Qt.AlignCenter)
            pm = QIcon(str(image_path)).pixmap(QSize(1600, 520))
            if pm is not None and not pm.isNull():
                # slightly larger banner for better visual impact
                lab.setPixmap(pm.scaledToWidth(1120, Qt.SmoothTransformation))
            bl.addWidget(lab)
            layout.addWidget(banner)

        gridw = QWidget(self)
        g = QGridLayout(gridw)
        g.setContentsMargins(0, 0, 0, 0)
        g.setHorizontalSpacing(14)
        g.setVerticalSpacing(14)

        ordered: List[ToolSpec] = []
        for tid in tool_ids:
            t = self.win.tools_by_id.get(tid)
            if t is not None:
                ordered.append(t)

        for idx, t in enumerate(ordered):
            r = idx // 3
            c = idx % 3
            tile = HomeTile(
                t.title,
                t.category,
                icon=self.win.get_tool_icon(t.id),
                image_path=None,
                on_click=lambda tt=t: self.win.open_tool(tt.id),
                parent=self,
                art_height=56,
                min_height=120,
            )
            g.addWidget(tile, r, c)

        layout.addWidget(gridw)
        layout.addStretch(1)
class ToolInterface(QWidget):
    def __init__(self, win: 'FluentMainWindow', tool: ToolSpec, parent=None):
        super().__init__(parent)
        self.win = win
        self.tool = tool
        self.setObjectName(f"tool_{_slug(tool.id)}")

        self.arg_widgets: Dict[str, FluentArgWidget] = {}

        # root layout
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 18, 28, 18)
        root.setSpacing(12)

        # header
        header = QWidget(self)
        hl = QHBoxLayout(header)
        hl.setContentsMargins(0, 0, 0, 0)
        hl.setSpacing(10)

        title = TitleLabel(f"{tool.id} — {tool.title}", header)
        hl.addWidget(title, 1)

        self.btn_manual = PushButton("Manual", header, icon=FIF.HELP)
        self.btn_manual.clicked.connect(self._open_manual)
        self.btn_manual.setEnabled(bool(tool.docs_path))
        hl.addWidget(self.btn_manual)

        self.btn_load = PushButton("Load preset", header, icon=FIF.DOWNLOAD)
        self.btn_load.clicked.connect(self._load_preset)
        hl.addWidget(self.btn_load)

        self.btn_save = PushButton("Save preset", header, icon=FIF.SAVE)
        self.btn_save.clicked.connect(self._save_preset)
        hl.addWidget(self.btn_save)

        root.addWidget(header)

        if tool.description:
            desc = CaptionLabel(tool.description.strip(), self)
            desc.setWordWrap(True)
            root.addWidget(desc)

        # scroll area for parameter cards
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.NoFrame)
        root.addWidget(scroll, 1)

        content = QWidget(scroll)
        scroll.setWidget(content)
        content_l = QVBoxLayout(content)
        content_l.setContentsMargins(0, 0, 0, 0)
        content_l.setSpacing(12)

        # Run settings card
        rs = CardWidget(content)
        rs_l = QVBoxLayout(rs)
        rs_l.setContentsMargins(18, 16, 18, 16)
        rs_l.setSpacing(10)
        rs_l.addWidget(BodyLabel("Run settings", rs))

        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignRight)
        form.setHorizontalSpacing(12)
        form.setVerticalSpacing(10)

        # python
        self.python_edit = LineEdit(rs)
        self.python_edit.setText(self.win.python_exe)
        self.python_edit.textChanged.connect(lambda _: self.win.set_python_exe(self.python_edit.text().strip()))
        py_row = QWidget(rs)
        py_l = QHBoxLayout(py_row)
        py_l.setContentsMargins(0, 0, 0, 0)
        py_l.setSpacing(8)
        py_l.addWidget(self.python_edit, 1)
        py_browse = ToolButton(FIF.FOLDER, rs)
        py_browse.setToolTip("Browse Python")
        py_browse.clicked.connect(self._browse_python)
        py_l.addWidget(py_browse)
        form.addRow("Python", py_row)

        # cwd
        self.cwd_edit = LineEdit(rs)
        self.cwd_edit.setText(self.win.cwd)
        self.cwd_edit.textChanged.connect(lambda _: self.win.set_cwd(self.cwd_edit.text().strip()))
        cwd_row = QWidget(rs)
        cwd_l = QHBoxLayout(cwd_row)
        cwd_l.setContentsMargins(0, 0, 0, 0)
        cwd_l.setSpacing(8)
        cwd_l.addWidget(self.cwd_edit, 1)
        cwd_browse = ToolButton(FIF.FOLDER, rs)
        cwd_browse.setToolTip("Browse working directory")
        cwd_browse.clicked.connect(self._browse_cwd)
        cwd_l.addWidget(cwd_browse)
        form.addRow("Working dir", cwd_row)

        rs_l.addLayout(form)
        content_l.addWidget(rs)

        # Parameter groups
        for group_name, args in group_args(tool.args):
            card = CardWidget(content)
            card_l = QVBoxLayout(card)
            card_l.setContentsMargins(18, 16, 18, 16)
            card_l.setSpacing(10)
            card_l.addWidget(BodyLabel(group_name, card))

            fl = QFormLayout()
            fl.setLabelAlignment(Qt.AlignRight)
            fl.setHorizontalSpacing(12)
            fl.setVerticalSpacing(10)

            for a in args:
                w = FluentArgWidget(a, card)
                label = a.display_name
                if a.required:
                    label = f"{label} *"
                lab = CaptionLabel(label, card)
                if a.help:
                    lab.setToolTip(a.help)
                    w.setToolTip(a.help)
                fl.addRow(lab, w)
                self.arg_widgets[a.dest] = w

            card_l.addLayout(fl)
            content_l.addWidget(card)

        # Command preview + actions
        cmd_card = CardWidget(content)
        cmd_l = QVBoxLayout(cmd_card)
        cmd_l.setContentsMargins(18, 16, 18, 16)
        cmd_l.setSpacing(10)
        cmd_l.addWidget(BodyLabel("Command", cmd_card))

        self.cmd_preview = LineEdit(cmd_card)
        self.cmd_preview.setReadOnly(True)
        cmd_l.addWidget(self.cmd_preview)

        act_row = QWidget(cmd_card)
        ar = QHBoxLayout(act_row)
        ar.setContentsMargins(0, 0, 0, 0)
        ar.setSpacing(8)

        self.btn_preview = PushButton("Preview", act_row, icon=FIF.VIEW)
        self.btn_preview.clicked.connect(self._update_preview)
        ar.addWidget(self.btn_preview)

        self.btn_copy = PushButton("Copy", act_row, icon=FIF.COPY)
        self.btn_copy.clicked.connect(lambda: QApplication.clipboard().setText(self.cmd_preview.text()))
        ar.addWidget(self.btn_copy)

        ar.addStretch(1)

        self.btn_run = PrimaryPushButton("Run", act_row, icon=FIF.PLAY)
        self.btn_run.clicked.connect(self._run)
        ar.addWidget(self.btn_run)

        self.btn_stop = PushButton("Stop", act_row, icon=FIF.CANCEL)
        self.btn_stop.clicked.connect(self._stop)
        self.btn_stop.setEnabled(False)
        ar.addWidget(self.btn_stop)

        cmd_l.addWidget(act_row)
        content_l.addWidget(cmd_card)

        # Log
        log_card = CardWidget(content)
        log_l = QVBoxLayout(log_card)
        log_l.setContentsMargins(18, 16, 18, 16)
        log_l.setSpacing(10)
        log_l.addWidget(BodyLabel("Log", log_card))

        self.log = PlainTextEdit(log_card)
        self.log.setReadOnly(True)
        self.log.setMinimumHeight(200)
        font = QFont("Consolas")
        font.setPointSize(10)
        self.log.setFont(font)
        log_l.addWidget(self.log)
        content_l.addWidget(log_card)

        content_l.addStretch(1)

        # initial preset + preview
        self._load_preset(silent=True)
        self._update_preview()

    # -----------------
    # Build / validate
    # -----------------
    def _collect_args(self) -> Dict[str, Any]:
        return {k: w.value() for k, w in self.arg_widgets.items()}

    def _validate(self) -> Optional[str]:
        for arg in self.tool.args:
            if not arg.required:
                continue
            w = self.arg_widgets.get(arg.dest)
            if not w:
                continue
            v = w.value()
            action = (arg.action or "").lower()
            if action in ("store_true", "store_false"):
                continue
            if v is None or (isinstance(v, str) and v.strip() == ""):
                return f"Missing required argument: {arg.display_name}"
        return None

    def build_command(self) -> List[str]:
        pyexe = self.win.python_exe or sys.executable
        script = str(self.tool.script_path)
        argv: List[str] = [pyexe, script]

        for arg in self.tool.args:
            w = self.arg_widgets.get(arg.dest)
            if not w:
                continue
            v = w.value()
            action = (arg.action or "").lower()

            if action == "store_true":
                if bool(v):
                    argv.append(arg.long_flag or arg.display_name)
                continue
            if action == "store_false":
                if not bool(v):
                    argv.append(arg.long_flag or arg.display_name)
                continue

            if arg.is_positional:
                if isinstance(v, str) and v.strip():
                    argv.extend(shlex.split(v))
                continue

            flag = arg.long_flag or arg.display_name
            if isinstance(v, str):
                if v.strip() == "":
                    continue
                argv.extend([flag, v])
            else:
                if v is None:
                    continue
                argv.extend([flag, str(v)])

        return argv

    def _update_preview(self):
        err = self._validate()
        if err:
            self.cmd_preview.setText(f"[Invalid] {err}")
            return
        argv = self.build_command()
        self.cmd_preview.setText(" ".join(shlex.quote(x) for x in argv))

    # -----------------
    # Run / stop
    # -----------------
    def _run(self):
        self._update_preview()
        err = self._validate()
        if err:
            InfoBar.error(
                title="Missing arguments",
                content=err,
                orient=Qt.Horizontal,
                isClosable=True,
                position=InfoBarPosition.TOP,
                duration=3500,
                parent=self,
            )
            return

        if self.win.proc and self.win.proc.state() != QProcess.NotRunning:
            InfoBar.warning(
                title="Already running",
                content="A process is already running. Stop it first.",
                orient=Qt.Horizontal,
                isClosable=True,
                position=InfoBarPosition.TOP,
                duration=3500,
                parent=self,
            )
            return

        argv = self.build_command()
        pyexe = argv[0]
        args = argv[1:]

        self.log.appendPlainText(f"$ {' '.join(shlex.quote(x) for x in argv)}\n")

        proc = QProcess(self)
        proc.setProgram(pyexe)
        proc.setArguments(args)
        proc.setWorkingDirectory(self.win.cwd or os.getcwd())

        proc.readyReadStandardOutput.connect(lambda: self._on_stdout(proc))
        proc.readyReadStandardError.connect(lambda: self._on_stderr(proc))
        proc.finished.connect(lambda code, status: self._on_finished(code, status))

        self.win.proc = proc
        self.btn_run.setEnabled(False)
        self.btn_stop.setEnabled(True)

        proc.start()

        if not proc.waitForStarted(5000):
            InfoBar.error(
                title="Failed to start",
                content="Could not start the process.",
                orient=Qt.Horizontal,
                isClosable=True,
                position=InfoBarPosition.TOP,
                duration=4000,
                parent=self,
            )
            self.btn_run.setEnabled(True)
            self.btn_stop.setEnabled(False)
            self.win.proc = None

    def _stop(self):
        if self.win.proc and self.win.proc.state() != QProcess.NotRunning:
            self.win.proc.kill()
            self.log.appendPlainText("\n[INFO] Process killed by user.\n")

    def _on_stdout(self, proc: QProcess):
        data = proc.readAllStandardOutput().data().decode("utf-8", errors="ignore")
        if data:
            self.log.appendPlainText(data.rstrip("\n"))

    def _on_stderr(self, proc: QProcess):
        data = proc.readAllStandardError().data().decode("utf-8", errors="ignore")
        if data:
            self.log.appendPlainText(data.rstrip("\n"))

    def _on_finished(self, exit_code: int, exit_status):
        self.log.appendPlainText(f"\n[DONE] exit_code={exit_code}\n")
        self.btn_run.setEnabled(True)
        self.btn_stop.setEnabled(False)
        self.win.proc = None

        InfoBar.success(
            title="Completed",
            content=f"{self.tool.id} finished (exit_code={exit_code})",
            orient=Qt.Horizontal,
            isClosable=True,
            position=InfoBarPosition.TOP,
            duration=3000,
            parent=self,
        )

    # -----------------
    # Presets
    # -----------------
    def _load_preset(self, silent: bool = False):
        p = preset_path(self.win.presets_dir, self.tool.id)
        data = load_preset(p)
        if not data:
            if not silent:
                InfoBar.info(
                    title="Preset",
                    content="No preset found for this tool.",
                    orient=Qt.Horizontal,
                    isClosable=True,
                    position=InfoBarPosition.TOP,
                    duration=2500,
                    parent=self,
                )
            return
        for k, v in data.items():
            w = self.arg_widgets.get(k)
            if w:
                w.set_value(v)
        self._update_preview()
        if not silent:
            InfoBar.success(
                title="Preset loaded",
                content=p.name,
                orient=Qt.Horizontal,
                isClosable=True,
                position=InfoBarPosition.TOP,
                duration=2500,
                parent=self,
            )

    def _save_preset(self):
        data = self._collect_args()
        p = preset_path(self.win.presets_dir, self.tool.id)
        save_preset(p, data)
        InfoBar.success(
            title="Preset saved",
            content=p.name,
            orient=Qt.Horizontal,
            isClosable=True,
            position=InfoBarPosition.TOP,
            duration=2500,
            parent=self,
        )

    # -----------------
    # Manual
    # -----------------
    def _open_manual(self):
        if not self.tool.docs_path:
            return
        txt = self.tool.docs_path.read_text(encoding="utf-8", errors="ignore")
        # Use a fluent-ish in-page dialog via InfoBar + log for now
        self.log.appendPlainText("\n" + "=" * 60 + "\n[MANUAL]\n" + txt + "\n" + "=" * 60 + "\n")
        InfoBar.info(
            title="Manual",
            content="Manual content appended to the log panel.",
            orient=Qt.Horizontal,
            isClosable=True,
            position=InfoBarPosition.TOP,
            duration=2500,
            parent=self,
        )

    # -----------------
    # Browse
    # -----------------
    def _browse_python(self):
        f, _ = QFileDialog.getOpenFileName(self, "Select Python executable", os.getcwd(), "All files (*.*)")
        if f:
            self.python_edit.setText(f)
            self.win.set_python_exe(f)
            self._update_preview()

    def _browse_cwd(self):
        d = QFileDialog.getExistingDirectory(self, "Select working directory", os.getcwd())
        if d:
            self.cwd_edit.setText(d)
            self.win.set_cwd(d)


class SettingsInterface(QWidget):
    def __init__(self, win: 'FluentMainWindow', parent=None):
        super().__init__(parent)
        self.win = win
        self.setObjectName("settings")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 22, 28, 22)
        layout.setSpacing(14)

        layout.addWidget(TitleLabel("Settings", self))
        layout.addWidget(CaptionLabel("Theme and appearance", self))

        card = CardWidget(self)
        cl = QVBoxLayout(card)
        cl.setContentsMargins(18, 16, 18, 16)
        cl.setSpacing(12)

        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignRight)
        form.setHorizontalSpacing(12)
        form.setVerticalSpacing(10)

        # Theme
        self.theme = ComboBox(self)
        self.theme.addItems(["Auto", "Light", "Dark"])
        self.theme.setCurrentText("Auto")
        self.theme.currentTextChanged.connect(self._apply_theme)
        form.addRow("Theme", self.theme)

        # Accent
        self.accent = ComboBox(self)
        self.accent.addItems(["Blue", "Teal", "Green", "Orange", "Pink", "Purple"])
        self.accent.setCurrentText("Blue")
        self.accent.currentTextChanged.connect(self._apply_accent)
        form.addRow("Accent", self.accent)

        cl.addLayout(form)
        layout.addWidget(card)
        layout.addStretch(1)

    def _apply_theme(self, t: str):
        if t.lower() == "light":
            setTheme(Theme.LIGHT)
        elif t.lower() == "dark":
            setTheme(Theme.DARK)
        else:
            setTheme(Theme.AUTO)

    def _apply_accent(self, a: str):
        # hex values are conservative and work cross-platform
        mp = {
            "Blue": "#0078D4",
            "Teal": "#00B7C3",
            "Green": "#107C10",
            "Orange": "#D83B01",
            "Pink": "#E3008C",
            "Purple": "#5C2D91",
        }
        setThemeColor(mp.get(a, "#0078D4"))


# -------------------------
# Fluent main window
# -------------------------

class FluentMainWindow(FluentWindow):
    def __init__(self, root_dir: Path):
        super().__init__()

        self.root_dir = root_dir
        self.tools_dir = root_dir / "tools"
        self.docs_dir = root_dir / "docs"
        self.presets_dir = root_dir / "presets"
        self.logs_dir = root_dir / "logs"
        self.logs_dir.mkdir(parents=True, exist_ok=True)

        self.python_exe: str = sys.executable
        self.cwd: str = os.getcwd()

        self.proc: Optional[QProcess] = None

        # theme
        setTheme(Theme.AUTO)
        try:
            self.setMicaEffectEnabled(True)  # only works on Win11
        except Exception:
            pass

        self.setWindowTitle("OmicsCanvas GUI")
        self.resize(1320, 820)

        self.tools: List[ToolSpec] = discover_tools(self.tools_dir, self.docs_dir)

        self.tools_by_id: Dict[str, ToolSpec] = {t.id: t for t in self.tools}
        self.tool_interfaces: Dict[str, ToolInterface] = {}
        self.home_assets_dir = self.root_dir / 'assets' / 'home'
        self.module_interfaces: Dict[str, ModuleInterface] = {}


        self._build_navigation()

    def set_python_exe(self, path: str):
        if path:
            self.python_exe = path

    def set_cwd(self, path: str):
        if path:
            self.cwd = path

    

    def get_tool_icon(self, tool_id: str) -> QIcon:
        """Return a per-tool QIcon (generated icons in assets/icons/tools)."""
        p = self.root_dir / "assets" / "icons" / "tools" / f"tool_{tool_id}.png"
        if p.exists():
            return QIcon(str(p))
        # fallbacks
        p2 = self.root_dir / "assets" / "icons" / "tools" / f"{tool_id}.png"
        if p2.exists():
            return QIcon(str(p2))
        return FIF.DOCUMENT.icon()

    def _build_navigation(self):
        # Home
        self.homeInterface = HomeInterface(self, self)
        self.addSubInterface(self.homeInterface, FIF.HOME, "Home")

        # Models: curated entry points (banner + grouped scripts)
        self.modelsRoot = QWidget(self)
        self.modelsRoot.setObjectName("models")
        m2l = QVBoxLayout(self.modelsRoot)
        m2l.setContentsMargins(28, 22, 28, 22)
        m2l.setSpacing(10)
        m2l.addWidget(TitleLabel("Models", self.modelsRoot))
        m2l.addWidget(CaptionLabel("Curated entry points with banners.", self.modelsRoot))
        m2l.addStretch(1)
        self.addSubInterface(self.modelsRoot, FIF.APPLICATION, "Models")

        for m in MODELS:
            img_path = self.home_assets_dir / m["image"]
            mi = ModuleInterface(self, m["name"], m["tool_ids"], image_path=img_path, parent=self)
            self.module_interfaces[m["name"]] = mi
            self.addSubInterface(mi, FIF.APPLICATION, m["name"], parent=self.modelsRoot, position=NavigationItemPosition.TOP)

        

        # Modules: every script (01–19)
        self.modulesRoot = QWidget(self)
        self.modulesRoot.setObjectName("modules")
        mrl = QVBoxLayout(self.modulesRoot)
        mrl.setContentsMargins(28, 22, 28, 22)
        mrl.setSpacing(10)
        mrl.addWidget(TitleLabel("Modules", self.modulesRoot))
        mrl.addWidget(CaptionLabel("All scripts (01–19).", self.modulesRoot))
        mrl.addStretch(1)
        self.addSubInterface(self.modulesRoot, FIF.DOCUMENT, "Modules")

        for tool in sorted(self.tools, key=lambda x: x.id):
            ti = ToolInterface(self, tool, self)
            self.tool_interfaces[tool.id] = ti
            # show functional name instead of numeric IDs in the navigation tree
            self.addSubInterface(
                ti,
                self.get_tool_icon(tool.id),
                tool.title,
                parent=self.modulesRoot,
                position=NavigationItemPosition.TOP,
            )

        

        # Other curated entry points
        if OTHER_MODELS:
            self.otherRoot = QWidget(self)
            self.otherRoot.setObjectName("other")
            orl = QVBoxLayout(self.otherRoot)
            orl.setContentsMargins(28, 22, 28, 22)
            orl.setSpacing(10)
            orl.addWidget(TitleLabel("Other", self.otherRoot))
            orl.addWidget(CaptionLabel("Less frequently used entry points.", self.otherRoot))
            orl.addStretch(1)
            # Use a conservative icon name for compatibility across qfluentwidgets versions
            self.addSubInterface(self.otherRoot, FIF.MENU, "Other")

            for m in OTHER_MODELS:
                img_path = self.home_assets_dir / m["image"]
                mi = ModuleInterface(self, m["name"], m["tool_ids"], image_path=img_path, parent=self)
                self.module_interfaces[m["name"]] = mi
                self.addSubInterface(mi, FIF.APPLICATION, m["name"], parent=self.otherRoot, position=NavigationItemPosition.TOP)

        # Bottom: settings
        self.settingsInterface = SettingsInterface(self, self)
        self.addSubInterface(self.settingsInterface, FIF.SETTING, "Settings", position=NavigationItemPosition.BOTTOM)




    def open_tool(self, tool_id: str):
        w = self.tool_interfaces.get(tool_id)
        if w is None:
            InfoBar.warning(
                title="Not found",
                content=f"Tool not found: {tool_id}",
                orient=Qt.Horizontal,
                isClosable=True,
                position=InfoBarPosition.TOP,
                duration=2500,
                parent=self,
            )
            return
        self.switchTo(w)
        try:
            self.navigationInterface.setCurrentItem(w.objectName())
        except Exception:
            pass
    def _search_and_jump(self):
        q = self.homeInterface.search.text().strip().lower()
        if not q:
            return
        # Find best match by id/title
        best: Optional[ToolSpec] = None
        for t in self.tools:
            if q in (t.id or "").lower() or q in (t.title or "").lower() or q in (t.script_path.name.lower()):
                best = t
                break
        if not best:
            InfoBar.warning(
                title="Not found",
                content=f"No tool matched: {q}",
                orient=Qt.Horizontal,
                isClosable=True,
                position=InfoBarPosition.TOP,
                duration=2500,
                parent=self,
            )
            return
        # Route key is interface objectName; switchTo expects a QWidget
        route = f"tool_{_slug(best.id)}"
        w = self.findChild(QWidget, route)
        if w is None:
            InfoBar.info(
                title="Navigation",
                content=f"Found {best.id}, but could not locate its UI page. Use left navigation.",
                orient=Qt.Horizontal,
                isClosable=True,
                position=InfoBarPosition.TOP,
                duration=3000,
                parent=self,
            )
            return
        try:
            self.switchTo(w)
            # highlight nav item if possible
            try:
                self.navigationInterface.setCurrentItem(route)
            except Exception:
                pass
        except Exception:
            InfoBar.info(
                title="Navigation",
                content=f"Found {best.id}, but could not switch automatically. Use left navigation.",
                orient=Qt.Horizontal,
                isClosable=True,
                position=InfoBarPosition.TOP,
                duration=3000,
                parent=self,
            )


def main(argv: Optional[List[str]] = None):
    root_dir = Path(__file__).resolve().parent
    app = QApplication(sys.argv if argv is None else argv)

    # High-DPI hints (safe defaults)
    try:
        app.setAttribute(Qt.AA_EnableHighDpiScaling, True)
        app.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    except Exception:
        pass

    win = FluentMainWindow(root_dir)
    win.show()
    sys.exit(app.exec())
