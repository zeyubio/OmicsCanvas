from __future__ import annotations

import ast
import os
import re
import sys
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional, List, Dict, Tuple


# -------------------------
# Data models
# -------------------------

@dataclass
class ArgumentSpec:
    # raw flags, like ["-b","--bam"] or positional like ["inputs"]
    flags: List[Any]
    kwargs: Dict[str, Any] = field(default_factory=dict)

    @property
    def is_positional(self) -> bool:
        return bool(self.flags) and isinstance(self.flags[0], str) and (not self.flags[0].startswith("-"))

    @property
    def long_flag(self) -> Optional[str]:
        for f in self.flags:
            if isinstance(f, str) and f.startswith("--"):
                return f
        # if only short flag exists, return it
        for f in self.flags:
            if isinstance(f, str) and f.startswith("-"):
                return f
        return None

    @property
    def dest(self) -> str:
        # argparse default dest behavior:
        # take the first long option, strip leading '--', replace '-' with '_'
        if self.is_positional:
            return str(self.flags[0])
        lf = self.long_flag
        if lf:
            d = lf.lstrip("-")
            return d.replace("-", "_")
        return "arg"

    @property
    def display_name(self) -> str:
        lf = self.long_flag
        if lf:
            return lf
        if self.is_positional:
            return str(self.flags[0])
        return "/".join([str(x) for x in self.flags if x is not None])

    @property
    def required(self) -> bool:
        return bool(self.kwargs.get("required", False)) or self.is_positional

    @property
    def default(self) -> Any:
        return self.kwargs.get("default", None)

    @property
    def action(self) -> Optional[str]:
        a = self.kwargs.get("action", None)
        return str(a) if a is not None else None

    @property
    def choices(self) -> Optional[List[Any]]:
        c = self.kwargs.get("choices", None)
        return list(c) if isinstance(c, (list, tuple)) else None

    @property
    def type_name(self) -> Optional[str]:
        t = self.kwargs.get("type", None)
        if t is None:
            return None
        return str(t)

    @property
    def help(self) -> str:
        h = self.kwargs.get("help", "") or ""
        return str(h)


@dataclass
class ToolSpec:
    id: str
    script_path: Path
    title: str
    category: str
    description: str = ""
    docs_path: Optional[Path] = None
    args: List[ArgumentSpec] = field(default_factory=list)


# -------------------------
# AST parsing (no import)
# -------------------------

def _literal_eval_safe(node: ast.AST) -> Any:
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.Str):
        return node.s
    if isinstance(node, ast.Num):
        return node.n
    if isinstance(node, ast.NameConstant):
        return node.value
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
        v = _literal_eval_safe(node.operand)
        if isinstance(v, (int, float)):
            return -v
    if isinstance(node, ast.List):
        return [_literal_eval_safe(e) for e in node.elts]
    if isinstance(node, ast.Tuple):
        return tuple(_literal_eval_safe(e) for e in node.elts)
    if isinstance(node, ast.Dict):
        out = {}
        for k, v in zip(node.keys, node.values):
            out[_literal_eval_safe(k)] = _literal_eval_safe(v)
        return out
    return None


def _type_name(node: ast.AST) -> Optional[str]:
    # Supports "int"/"float"/"str" and qualified names.
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    # fallback for more complex expressions (keep as text)
    try:
        return ast.unparse(node)  # py3.9+
    except Exception:
        return None


def parse_argparse_from_script(script_path: Path) -> Tuple[List[ArgumentSpec], str]:
    """Return (arguments, docstring)."""
    src = script_path.read_text(encoding="utf-8", errors="ignore")
    try:
        tree = ast.parse(src, filename=str(script_path))
    except SyntaxError:
        # keep GUI usable even if a single tool has syntax issues
        return [], ""

    doc = ast.get_docstring(tree) or ""

    args: List[ArgumentSpec] = []

    class V(ast.NodeVisitor):
        def visit_Call(self, node: ast.Call):
            func = node.func
            if isinstance(func, ast.Attribute) and func.attr == "add_argument":
                flags: List[Any] = []
                kwargs: Dict[str, Any] = {}
                for a in node.args:
                    v = _literal_eval_safe(a)
                    flags.append(v)
                for kw in node.keywords:
                    if kw.arg is None:
                        continue
                    if kw.arg == "type":
                        kwargs["type"] = _type_name(kw.value)
                    else:
                        kwargs[kw.arg] = _literal_eval_safe(kw.value)
                args.append(ArgumentSpec(flags=flags, kwargs=kwargs))
            self.generic_visit(node)

    V().visit(tree)
    return args, doc


# -------------------------
# Tool discovery + metadata
# -------------------------

def _tool_number_from_filename(name: str) -> Optional[int]:
    m = re.match(r"^(\d{2})_", name)
    if not m:
        return None
    try:
        return int(m.group(1))
    except Exception:
        return None


def default_category(n: Optional[int]) -> str:
    """Default category for UI grouping.

    These categories are used in subtitles and the left navigation grouping.
    You can still override tool membership via the Home "Models".
    """
    if n is None:
        return "Other"
    if 1 <= n <= 4:
        return "Data Prepare"
    if 5 <= n <= 7:
        return "Calculate Matrix"
    if 8 <= n <= 9:
        return "RNA Analysis"
    if n == 10:
        return "Circos Plot"
    if n == 11:
        return "ChIP-seq Analysis"
    if 12 <= n <= 13:
        return "Heatmap & Clustering"
    if 14 <= n <= 16:
        return "Methylation Analysis"
    if 17 <= n <= 18:
        return "Single-gene Plot"
    if n == 19:
        return "GO Enrichment"
    return "Other"

    if 1 <= n <= 4:
        return "Prepare"
    if 5 <= n <= 7:
        return "Quantification / Matrices"
    if 8 <= n <= 9:
        return "Differential Expression"
    if n in (10, 13, 14):
        return "Meta-profile / Heatmap"
    if n in (11, 12):
        return "Heatmap / Clustering"
    if n in (15, 16):
        return "Single-gene Visualization"
    if n in (17, 18):
        return "Genome-wide / QC"
    if n == 19:
        return "GO Enrichment"
    return "Other"

def _looks_like_filename_line(s: str) -> bool:
    s2 = str(s).strip()
    if not s2:
        return False
    low = s2.lower()
    if ".py" in low:
        return True
    # likely a stem-like line: many underscores, no spaces
    if ("_" in s2) and (" " not in s2) and len(s2) < 120:
        return True
    return False


def _prettify_tool_title(stem: str) -> str:
    """Convert '05_compute_bam_to_gene_matrices' -> 'Compute BAM to Gene Matrices'."""
    s = re.sub(r"^\d{2}_", "", str(stem).strip())
    s = s.replace("-", "_")
    parts = [p for p in s.split("_") if p]
    acr = {
        "gff": "GFF", "gff3": "GFF3", "bed": "BED", "bam": "BAM", "cx": "CX",
        "rna": "RNA", "de": "DE", "go": "GO", "tss": "TSS", "tes": "TES",
        "fpkm": "FPKM", "tpm": "TPM", "nb": "NB", "qc": "QC",
        "chip": "ChIP", "seq": "seq",  # keep ChIP-seq formatting later
        "2d": "2D", "3d": "3D",
    }
    out = []
    for p in parts:
        low = p.lower()
        if low in acr:
            out.append(acr[low])
        elif low == "vs":
            out.append("vs")
        else:
            out.append(low.capitalize())
    title = " ".join(out).replace("ChIP seq", "ChIP-seq").replace("Chip seq", "ChIP-seq")
    title = title.replace("2D 3D", "2D/3D").replace("3D 2D", "2D/3D")
    return title.strip() or stem


# A small override map (titles/docs) to make the GUI nicer.
# You can edit this file without touching the GUI code.
TOOL_OVERRIDES: Dict[str, Dict[str, Any]] = {
    # Prepare
    "01_prepare_gff_to_bed_genes_length.py": {
        "title": "Prepare GFF3 → BED + gene length table",
        "docs": "01_prepare_gff_to_bed_genes_length.README.md",
    },
    "02_prepare_cx_context_split.py": {
        "title": "Split CX by context (CG/CHG/CHH)",
        "docs": "02_prepare_cx_context_split.py.README.md",
    },
    "03_prepare_cx_replicate_merge.py": {
        "title": "Merge CX replicates",
        "docs": "03_prepare_cx_replicate_merge.README.md",
    },
    "04_prepare_extract_gene_methylation.py": {
        "title": "Extract gene methylation from CX",
        "docs": "4OmicsCanvas_Extract_Gene_Methylation_EN.updated.md",
    },

    # Calculate matrix / quantification
    "05_compute_bam_to_gene_matrices.py": {
        "title": "BAM → gene-centric matrices (TSS/gene/TES)",
        "docs": "5OmicsCanvas_Step2_BAM_to_Matrices_EN.updated.md",
    },
    "06_compute_cx_gene_matrix.py": {
        "title": "CX → methylation matrices (gene / bins)",
        "docs": "06_compute_cx_gene_matrix.py.README.md",
    },
    "07_compute_bam_to_fpkm.py": {
        "title": "BAM → counts/FPKM/TPM",
        "docs": "07_compute_bam_to_fpkm.py.README.md",
    },

    # RNA / DE
    "08_compute_nb_de.py": {
        "title": "Differential expression (Negative Binomial)",
        "docs": "08_compute_nb_de.py.README.md",
    },
    "09_compute_merge_expr_pairwise_de.py": {
        "title": "Merge expression + pairwise DE",
        "docs": "09_compute_merge_expr_pairwise_de.py.README.md",
    },

    # Plot
    "10_plot_genome_circos.py": {
        "title": "Genome-wide circos plot",
        "docs": "10_plot_genome_circos_Readme.updated.md",
    },
    "11_plot_whole_profile_2d3d.py": {
        "title": "Whole profile plot (2D/3D)",
        "docs": "11OmicsCanvas_Step3_Plot_Profiles_2D3D_EN.updated.md",
    },
    "12_plot_histone_vs_expr_heatmap.py": {
        "title": "Histone/track vs expression heatmap",
        "docs": "12_plot_histone_vs_expr_heatmap.README.md",
    },
    "13_plot_histone_cluster_pipline.py": {
        "title": "Heatmap clustering pipeline",
        "docs": "13OmicsCanvas_Histone_Cluster_Pipeline_EN.updated.md",
    },

    # Methylation
    "14_methylation_bin_correlation_triangle.py": {
        "title": "Methylation bin correlation (triangle heatmap)",
        "docs": "14OmicsCanvas_Methylation_Bin_Correlation_Triangle_EN.md",
    },
    "15_plot_methylation_profile_2d3d.py": {
        "title": "Methylation profile plot (2D/3D)",
        "docs": "15_plot_methylation_profile_2d3d.README.md",
    },
    "16_plot_meth_vs_expr_heatmap.py": {
        "title": "Methylation vs expression heatmap",
        "docs": "16_plot_meth_vs_expr_heatmap.README.md",
    },

    # Single-gene
    "17_plot_gene_tracks_2d3d_peaks.py": {
        "title": "Gene tracks (2D/3D + peaks)",
        "docs": "17_plot_gene_tracks_2d3d_peaks.README.md",
    },
    "18_plot_gene_circle_plot_peaks.py": {
        "title": "Gene circle plot (+ peaks)",
        "docs": "18_plot_gene_circle_plot_peaks.README.updated.md",
    },

    # Enrichment
    "19_omicscanvas_go_enrich.py": {
        "title": "GO enrichment (bubble plot)",
        "docs": "19_omicscanvas_go_enrich.README.md",
    },
}



def discover_tools(tools_dir: Path, docs_dir: Path) -> List[ToolSpec]:
    tools: List[ToolSpec] = []
    for p in sorted(tools_dir.glob("*.py")):
        if p.name.startswith("_"):
            continue
        n = _tool_number_from_filename(p.name)
        cat = default_category(n)

        args, doc = parse_argparse_from_script(p)
        doc_first = (doc.strip().splitlines()[0].strip() if doc.strip() else "")
        doc_title = "" if _looks_like_filename_line(doc_first) else doc_first
        ov = TOOL_OVERRIDES.get(p.name, {})
        title = ov.get("title") or doc_title or _prettify_tool_title(p.stem)
        docs_name = ov.get("docs", None)
        docs_path = (docs_dir / docs_name) if docs_name else None
        if docs_path and (not docs_path.exists()):
            docs_path = None

        desc = ""
        if doc:
            # take first paragraph as description
            lines = [x.strip() for x in doc.strip().splitlines()]
            # skip the first line (often filename)
            body = " ".join([x for x in lines[1:] if x])
            desc = body[:500]

        tool_id = f"{n:02d}" if n is not None else p.stem

        tools.append(
            ToolSpec(
                id=tool_id,
                script_path=p,
                title=title,
                category=cat,
                description=desc,
                docs_path=docs_path,
                args=args,
            )
        )

    # stable sorting: category then id
    tools.sort(key=lambda t: (t.category, t.id))
    return tools


# -------------------------
# Presets
# -------------------------

def preset_path(presets_dir: Path, tool_id: str) -> Path:
    return presets_dir / f"{tool_id}.json"


def load_preset(p: Path) -> Dict[str, Any]:
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_preset(p: Path, data: Dict[str, Any]) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
