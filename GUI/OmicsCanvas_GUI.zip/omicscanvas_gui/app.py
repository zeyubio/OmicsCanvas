"""OmicsCanvas GUI entrypoint.

Default: Fluent UI (Plan C) if PySide6-Fluent-Widgets is installed.
Fallback: Classic Qt UI.

CLI flags:
  --fluent   force Fluent UI
  --classic  force Classic UI
"""

from __future__ import annotations

import sys


def _strip_flag(argv: list[str], flag: str) -> list[str]:
    return [a for a in argv if a != flag]


def main(argv=None):
    argv = list(sys.argv if argv is None else argv)
    force_classic = "--classic" in argv
    force_fluent = "--fluent" in argv

    argv = _strip_flag(argv, "--classic")
    argv = _strip_flag(argv, "--fluent")

    if force_classic and force_fluent:
        # last one wins
        force_classic = False

    if not force_classic:
        try:
            # `qfluentwidgets` is provided by PySide6-Fluent-Widgets
            import qfluentwidgets  # noqa: F401
            from .fluent_app import main as fluent_main
            return fluent_main(argv)
        except Exception:
            # fall back
            pass

    from .classic_app import main as classic_main
    return classic_main(argv)


if __name__ == "__main__":
    main()
