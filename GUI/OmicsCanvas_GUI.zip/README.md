# OmicsCanvas GUI

This is a local desktop GUI wrapper for the 19 OmicsCanvas/BamTrackSuite command-line scripts you provided.

## Install

Create/activate a Python environment, then:

```bash
pip install -r requirements.txt
```

> Note: `pysam` is required for some BAM-based utilities and plotting scripts.

## Run

```bash
python -m omicscanvas_gui
```

### UI mode

- Default: Fluent UI (Plan C) if `PySide6-Fluent-Widgets` is installed
- Fallback: classic Qt UI

You can force the mode:

```bash
python -m omicscanvas_gui --fluent
python -m omicscanvas_gui --classic
```

## What the GUI does

- Discovers scripts under `omicscanvas_gui/tools/`
- Parses their `argparse` definitions (static AST parse, no importing) to build parameter forms
- Runs the selected script via `subprocess`/`QProcess` and streams logs into the GUI
- Supports saving/loading per-tool parameter presets (JSON)

## Folder layout

- `omicscanvas_gui/tools/` : your original scripts (script 13 is patched for a missing newline)
- `omicscanvas_gui/docs/`  : your Markdown manuals (from `read_me.zip`)
- `omicscanvas_gui/presets/` : saved parameter presets
- `omicscanvas_gui/logs/`  : GUI run logs

## Add new scripts later

Drop a `*.py` file into `omicscanvas_gui/tools/` (preferably with `argparse`), restart the GUI.

## Tutorial

See the full GUI user guide here:

- `omicscanvas_gui/docs/MANUAL.md`

It includes:
- A quick “click-through” tutorial for running tools in the GUI
- Recommended end-to-end workflows (Prepare → Matrix → Plot)
- Links to per-tool manuals for scripts 01–19
